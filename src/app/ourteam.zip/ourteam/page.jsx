import OurTeamComponent from '@/components/ourteamcomponent';
import React from 'react'

 const OurTeampage = () => {
  return (
    <div>
        <OurTeamComponent />
    </div>
  )
}

export default OurTeampage;
